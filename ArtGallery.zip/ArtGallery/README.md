# LegoStore
Pagina de productos de lego con el uso de json server para simular una api, ademas del uso de HTML, JS y CSS para las diferentes partes del proyecto

![Captura de pantalla 2024-07-14 132510](https://github.com/user-attachments/assets/63a5948c-c365-4e3f-922e-a5c15ffb6f91)
![Captura de pantalla 2024-07-14 132341](https://github.com/user-attachments/assets/2e011a1f-bbe7-4312-ad63-56efcaa898a1)
